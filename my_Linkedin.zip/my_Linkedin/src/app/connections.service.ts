import { Injectable, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Invitation} from './invitations/recieved/received';
import { sentInvitation} from './invitations/sent/sent';
//import {DataStruct} from '../app/connection-list/Interface/DataStruct';
@Injectable({
  providedIn: 'root'
})
export class ConnectionsService implements OnInit {
  url="http://10.102.55.71:8080/get-all-data";
  _urlGetConnectionCount = "http://10.102.55.71:8080/get-count/connections";
  _urlGetReceivedInvitations = "http://10.102.55.71:8080/get-invitations/received";
  _urlGetSentInvitations = "http://10.102.55.71:8080/get-invitations/sent";
  _urlGetAllConnections = "http://10.102.55.71:8080/get-all-connections";
  _urlAcceptInvitation = "http://10.102.55.71:8080/accept-invitation";
  _urlIgnoreInvitation = "http://10.102.55.71:8080/ignore-invitation";
  _urlRemoveConnection = "http://10.102.55.71:8080/remove-connection";
  _urlBlockConnection = "http://10.102.55.71:8080/block";
  _urlgetBlockedConnection = "http://10.102.55.71:8080/get-block-list";
  _urlUnblockConnection = "http://10.102.55.71:8080/unblock";

  constructor(private httpCaller:HttpClient) { }

  ngOnInit(){
    //this.getConnectionCount();
  }
  getdata(){
    return this.httpCaller.get(this.url)
  }

  getConnectionCount(user): Observable<any>{
    return this.httpCaller.post(this._urlGetConnectionCount, user);
  }

  getReceivedInvitations(user): Observable<any>{
    console.log(this.httpCaller.post(this._urlGetReceivedInvitations, user));
    return this.httpCaller.post(this._urlGetReceivedInvitations, user);
    // return ;
  }
  getSentInvitations(user): Observable<any>{
    return this.httpCaller.post(this._urlGetSentInvitations, user);
 
  }
  getAllConnections(user): Observable<any>{
    console.log(user);
    return this.httpCaller.post(this._urlGetAllConnections, user);
  }

  AcceptInvitation(user:string,requester:string): Observable<any>{
    console.log("request accepted");
    return this.httpCaller.post(this._urlAcceptInvitation, {"user":user,"requester":requester});
    // return this.getReceivedInvitations(user);
  }
  IgnoreInvitation(user:string,sender:string): Observable<any>{
    console.log("request ignored");
    return this.httpCaller.post(this._urlIgnoreInvitation, {"user":user,"sender":sender});
  }
  RemoveConnection(user:string,connection:string): Observable<any>{
    console.log('Connection removed');
    return this.httpCaller.post(this._urlRemoveConnection,{"user":user,"connection":connection})
  }
  BlockConnection(user:string,blockee:string): Observable<any>{
    console.log('Connection blocked');
    return this.httpCaller.post(this._urlBlockConnection,{"user":user,"blockee":blockee});
  }
   getBlockedConnection(user): Observable<any>{
    console.log(this.httpCaller.post(this._urlgetBlockedConnection, user));
    return this.httpCaller.post(this._urlgetBlockedConnection, user);
    
  }
  UnblockConnection(user:string,blockee:string): Observable<any>{
    console.log('Connection unblocked');
    return this.httpCaller.post(this._urlUnblockConnection,{"user":user,"blockee":blockee});
  }
}
