import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {sentInvitation} from './sent';
import { ConnectionsService} from '../../connections.service';

@Component({
  selector: 'app-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.css']
})
export class SentComponent implements OnInit {
invitations=[];
  constructor(private route:Router, private connectionService: ConnectionsService) { }

  ngOnInit() {
    this.getSentInvitations();
  }

  getSentInvitations(){
    console.log("getSentInvitations");
  this.connectionService.getSentInvitations({"user": "Nandkumar"}).subscribe(i => {this.invitations = i});
  }
}
