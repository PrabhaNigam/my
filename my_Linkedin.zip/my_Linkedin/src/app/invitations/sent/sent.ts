export class sentInvitation{
    _id:string;
    name: string;
    profile:string
}