import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Invitation} from './received';
import { ConnectionsService} from '../../connections.service';

@Component({
  selector: 'app-blocklist',
  templateUrl: './blocklist.component.html',
  styleUrls: ['./blocklist.component.css']
})
export class BlocklistComponent implements OnInit {
blocklist=[];
user:string="Nandkumar";
blockee:string='Jayasree Talluru';
  constructor(private route:Router, private connectionService: ConnectionsService) { }

  ngOnInit() {
    this.getBlockedConnection();
  }
getBlockedConnection(){
    console.log("getBlockConnection");
     this.connectionService.getBlockedConnection({"user": "Nandkumar"}).subscribe(b => {this.blocklist = b});
  }
  UnblockConnection(){
    console.log('connection unblocked');
  this.connectionService.UnblockConnection(this.user,this.blockee).subscribe(unblock=>this.blocklist=unblock);
}
}
