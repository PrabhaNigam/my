export class Invitation{
    _id:string;
    name: string;
    profile:string
}