import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {Invitation} from './received';
import { ConnectionsService} from '../../connections.service';

@Component({
  selector: 'app-recieved',
  templateUrl: './recieved.component.html',
  styleUrls: ['./recieved.component.css']
})
export class RecievedComponent implements OnInit {
  invitations=[];
 user:string="Nandkumar";
  requester:string='Jayasree Talluru';
  sender:string='Jayasree Talluru';
  constructor(private route:Router, private connectionService: ConnectionsService) { }

  ngOnInit() {
    this.getReceivedInvitations();
    // this.AcceptInvitation();
  }

  getReceivedInvitations(){
    console.log("getReceivedInvitations");
     this.connectionService.getReceivedInvitations({"user": "Nandkumar"}).subscribe(i => {this.invitations = i});
  }
AcceptInvitation(){
    console.log("requested accepted");
    console.log(this.user,this.requester);
     this.connectionService.AcceptInvitation(this.user,this.requester).subscribe(p => {this.invitations = p});
  }
IgnoreInvitation(){
    console.log("requested ignored");
    console.log(this.user,this.sender);
     this.connectionService.IgnoreInvitation(this.user,this.sender).subscribe(p => {this.invitations = p});
  }
}
