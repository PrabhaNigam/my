import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConnectionsService} from '../connections.service';
@Component({
  selector: 'app-invitations',
  templateUrl: './invitations.component.html',
  styleUrls: ['./invitations.component.css']
})
export class InvitationsComponent implements OnInit {
  connectionCount=0;
  constructor(private route:Router,private connectionService: ConnectionsService) { }

  ngOnInit() {
    //this.getConnectionCount();
  }

  // getConnectionCount(){
   // this.connectionService.getConnectionCount({"user": "Nandkumar"}).subscribe(count=>this.connectionCount=count);
  // }

}
