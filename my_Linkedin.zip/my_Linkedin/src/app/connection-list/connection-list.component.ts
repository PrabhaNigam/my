import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConnectionsService} from '../connections.service';
//import {DataStruct} from './Interface/DataStruct';
@Component({
  selector: 'app-connection-list',
  templateUrl: './connection-list.component.html',
  styleUrls: ['./connection-list.component.css']
})
export class ConnectionListComponent implements OnInit {
connectionCount=0;
connectionList:any=[];
blocklist=[];
user:string="Nandkumar";
connection:string="Jayasree Talluru";
blockee:string="Jayasree Talluru";

  constructor(private route:Router, private connectionService: ConnectionsService) {}

  ngOnInit() {
    this.getConnectionCount();
    this.getAllConnections();
  }

  getConnectionCount(){
    this.connectionService.getConnectionCount({"user": "Nandkumar"}).subscribe(count=>this.connectionCount=count  );
    
  }
  getAllConnections(){
    this.connectionService.getAllConnections({"user": "Nandkumar"}).subscribe(connection=>this.connectionList=connection );
    
}
RemoveConnection(){
  console.log('connection removed')
  this.connectionService.RemoveConnection(this.user,this.connection).subscribe(remove=>this.connectionList=remove);
}
BlockConnection(){
    console.log('connection blocked');
  this.connectionService.BlockConnection(this.user,this.blockee).subscribe(block=>this.blocklist=block);
  }

title = 'LinkedIn';
}