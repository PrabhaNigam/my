import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConnectionsService} from '../connections.service';
@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.css']
})
export class ConnectionsComponent implements OnInit {
  invitations=[];
  blocklist=[];
  connectionCount=0;
  connectionList = [] ;
  user:string="Nandkumar";
  requester:string='Jayasree Talluru';
  sender:string='Jayasree Talluru';
  connection:string='{{data.name}}';
  blockee:string='Jayasree Talluru';

  constructor(private route:Router, private connectionService: ConnectionsService) { }

  ngOnInit() {
    this.getConnectionCount();
    this.getAllConnections();
     this.getReceivedInvitations();
         this.getBlockedConnection();

    //  this.AcceptInvitation();
  }

  getConnectionCount(){
    this.connectionService.getConnectionCount({"user": "Nandkumar"}).subscribe(count=>this.connectionCount=count  );
  }
  getAllConnections(){
    this.connectionService.getAllConnections({"user": "Nandkumar"}).subscribe(connection=>this.connectionList=connection );
  }
  getReceivedInvitations(){
    console.log("getReceivedInvitations");
     this.connectionService.getReceivedInvitations({"user": "Nandkumar"}).subscribe(i => {this.invitations = i});
  }
  AcceptInvitation(){
    console.log("request accepted");
     this.connectionService.AcceptInvitation(this.user,this.requester).subscribe(p => {this.invitations = p});
  }
  IgnoreInvitation(){
    console.log("request ignored");
     this.connectionService.IgnoreInvitation(this.user,this.sender).subscribe(p => {this.invitations = p});
  }
  RemoveConnection(){
    console.log('connection removed');
  this.connectionService.RemoveConnection(this.user,this.connection).subscribe(remove=>this.connectionList=remove);
}
 BlockConnection(){
    console.log('connection blocked');
  this.connectionService.BlockConnection(this.user,this.blockee).subscribe(block=>this.blocklist=block);
}
 getBlockedConnection(){
    console.log("getBlockConnection");
     this.connectionService.getBlockedConnection({"user": "Nandkumar"}).subscribe(b => {this.blocklist = b});
  }
  UnblockConnection(){
    console.log('connection unblocked');
  this.connectionService.UnblockConnection(this.user,this.blockee).subscribe(unblock=>this.blocklist=unblock);
}
  
title = 'LinkedIn';
}
