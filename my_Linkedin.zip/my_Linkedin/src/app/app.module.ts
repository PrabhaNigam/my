import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from "@angular/router";
import { FilterPipe} from './connection-list/filter.pipe';
import { FormsModule }   from '@angular/forms';

import { AppComponent } from './app.component';
import { ConnectionsComponent } from './connections/connections.component';
import { InvitationsComponent } from './invitations/invitations.component';
import { SentComponent } from './invitations/sent/sent.component';
import { RecievedComponent } from './invitations/recieved/recieved.component';
import { HttpClientModule} from '@angular/common/http';
import { ConnectionListComponent } from './connection-list/connection-list.component';
import { BlocklistComponent } from './invitations/blocklist/blocklist.component'
@NgModule({
  declarations: [
    AppComponent,FilterPipe,
    ConnectionsComponent,
    InvitationsComponent,
    SentComponent,
    RecievedComponent,
    ConnectionListComponent,
    BlocklistComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
     HttpClientModule,
      RouterModule,
        RouterModule.forRoot([ 
       {
        path:'',
        component:ConnectionsComponent
      },
      {
        path:'recieved',
        component:RecievedComponent
      },
      {
        path:'blocklist',
        component:BlocklistComponent
      },
       
      {
        path:'connection-list',
        component:ConnectionListComponent
      },
      {
        path:'sent',
        component:SentComponent
      }])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
